package com.siteiaagent.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

public class MainActivity extends Activity {
    private static final String BASE_URL = "https://site-ia-agent-qhdehz.v2.appdeploy.ai";
    private static final String LOGIN_URL = BASE_URL + "/?mobileLink=1";
    private static final String PREFS = "site_ia_agent";
    private static final String SESSION_KEY = "mobile_session";

    private static final int BG = Color.rgb(7, 9, 15);
    private static final int PANEL = Color.rgb(15, 19, 27);
    private static final int BORDER = Color.rgb(39, 48, 61);
    private static final int TEXT = Color.rgb(239, 244, 250);
    private static final int MUTED = Color.rgb(141, 151, 171);
    private static final int ACCENT = Color.rgb(93, 255, 186);
    private static final int DARK_TEXT = Color.rgb(7, 17, 12);

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private LinearLayout root;
    private WebView apiWebView;
    private volatile boolean apiWebReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildRoot();

        if (!handleIntent(getIntent())) {
            if (getSession().isEmpty()) showLogin();
            else loadDashboard();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private boolean handleIntent(Intent intent) {
        Uri data = intent == null ? null : intent.getData();
        if (data == null) return false;
        if (!"siteiaagent".equalsIgnoreCase(data.getScheme()) || !"auth".equalsIgnoreCase(data.getHost())) return false;
        String code = data.getQueryParameter("code");
        if (code == null || code.trim().isEmpty()) {
            showLoginError("Le code de connexion est manquant. Réessaie.");
            return true;
        }
        exchangeCode(code.trim());
        return true;
    }

    private void buildRoot() {
        FrameLayout shell = new FrameLayout(this);
        shell.setBackgroundColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ));
        shell.addView(scroll, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ));

        apiWebView = new WebView(this);
        apiWebView.setAlpha(0f);
        WebSettings settings = apiWebView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setUserAgentString("Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36");
        apiWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                apiWebReady = true;
            }
        });
        FrameLayout.LayoutParams hidden = new FrameLayout.LayoutParams(1, 1);
        shell.addView(apiWebView, hidden);
        apiWebView.loadUrl(BASE_URL + "/");
        setContentView(shell);
    }

    private void clearRoot() {
        root.removeAllViews();
    }

    private void showLogin() {
        clearRoot();
        addSpacer(70);
        TextView icon = text("🤖", 40, TEXT, true);
        root.addView(icon);
        addSpacer(18);
        root.addView(kicker("SITE IA AGENT"));
        addSpacer(10);
        root.addView(text("Connecte ton compte", 34, TEXT, true));
        addSpacer(12);
        root.addView(paragraph("La connexion s’ouvre dans Chrome pour fonctionner correctement et rester sécurisée."));
        addSpacer(24);

        Button connect = primaryButton("Se connecter");
        connect.setOnClickListener(v -> openBrowserLogin());
        root.addView(connect, wideParams(54));
        addSpacer(16);
        root.addView(securityNote("Aucun mot de passe n’est enregistré dans l’application."));
    }

    private void showLoginError(String message) {
        showLogin();
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void openBrowserLogin() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(LOGIN_URL));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Impossible d’ouvrir Chrome.", Toast.LENGTH_LONG).show();
        }
    }

    private void exchangeCode(String code) {
        showLoading("Connexion en cours…");
        executor.submit(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("code", code);
                JSONObject response = request("/api/mobile/exchange", "POST", body, false);
                String session = response.optString("session", "");
                if (session.isEmpty()) throw new Exception("missing_session");
                prefs.edit().putString(SESSION_KEY, session).apply();
                runOnUiThread(this::loadDashboard);
            } catch (Exception e) {
                runOnUiThread(() -> showLoginError("Connexion impossible (" + safeError(e) + "). Réessaie depuis Chrome."));
            }
        });
    }

    private void loadDashboard() {
        showLoading("Chargement de ton agent…");
        executor.submit(() -> {
            try {
                JSONObject dashboard = request("/api/mobile/dashboard", "GET", null, true);
                runOnUiThread(() -> renderDashboard(dashboard));
            } catch (UnauthorizedException e) {
                prefs.edit().remove(SESSION_KEY).apply();
                runOnUiThread(() -> showLoginError("Ta session a expiré. Reconnecte-toi."));
            } catch (Exception e) {
                runOnUiThread(() -> showRetry("Impossible de charger ton agent."));
            }
        });
    }

    private void renderDashboard(JSONObject dashboard) {
        JSONObject profile = dashboard.optJSONObject("profile");
        JSONObject plan = dashboard.optJSONObject("plan");
        if (profile == null || plan == null) {
            showGoalScreen();
            return;
        }
        showDoneScreen(dashboard, profile);
    }

    private void showGoalScreen() {
        clearRoot();
        addSpacer(50);
        root.addView(kicker("UNE SEULE DÉCISION"));
        addSpacer(12);
        root.addView(text("Combien veux-tu viser par mois ?", 36, TEXT, true));
        addSpacer(12);
        root.addView(paragraph("Choisis simplement un montant. L’agent décidera du projet et de la stratégie pour toi."));
        addSpacer(26);

        EditText amount = new EditText(this);
        amount.setInputType(InputType.TYPE_CLASS_NUMBER);
        amount.setText("500");
        amount.setTextColor(TEXT);
        amount.setHintTextColor(MUTED);
        amount.setTextSize(34);
        amount.setGravity(Gravity.CENTER);
        amount.setSingleLine(true);
        amount.setPadding(dp(16), dp(10), dp(16), dp(10));
        amount.setBackground(panelDrawable());
        root.addView(amount, wideParams(72));
        addSpacer(8);
        TextView unit = text("€/mois", 15, MUTED, true);
        root.addView(unit);
        addSpacer(22);

        Button validate = primaryButton("Valider");
        validate.setOnClickListener(v -> {
            String raw = amount.getText().toString().trim();
            int objective;
            try {
                objective = Integer.parseInt(raw);
            } catch (Exception e) {
                objective = 0;
            }
            if (objective < 100 || objective > 20000) {
                Toast.makeText(this, "Choisis un montant entre 100 € et 20 000 €.", Toast.LENGTH_LONG).show();
                return;
            }
            createPlan(objective);
        });
        root.addView(validate, wideParams(54));
        addSpacer(16);
        root.addView(securityNote("Objectif ≠ revenu garanti. Après validation, l’agent continue côté serveur."));
    }

    private void createPlan(int objective) {
        showLoading("L’agent prépare tout…");
        executor.submit(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("objective", objective);
                body.put("budget", 0);
                body.put("timePerWeek", "0-1 h");
                body.put("experience", "Débutant");
                body.put("preference", "Laisse l’agent choisir");
                request("/api/mobile/plan", "POST", body, true);
                JSONObject dashboard = request("/api/mobile/dashboard", "GET", null, true);
                runOnUiThread(() -> renderDashboard(dashboard));
            } catch (UnauthorizedException e) {
                prefs.edit().remove(SESSION_KEY).apply();
                runOnUiThread(() -> showLoginError("Ta session a expiré. Reconnecte-toi."));
            } catch (Exception e) {
                runOnUiThread(() -> showRetry("Le plan n’a pas pu être créé."));
            }
        });
    }

    private void showDoneScreen(JSONObject dashboard, JSONObject profile) {
        clearRoot();
        addSpacer(48);
        TextView icon = text("✓", 34, DARK_TEXT, true);
        icon.setGravity(Gravity.CENTER);
        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setColor(ACCENT);
        iconBg.setCornerRadius(dp(18));
        icon.setBackground(iconBg);
        root.addView(icon, new LinearLayout.LayoutParams(dp(64), dp(64)));
        addSpacer(18);
        root.addView(kicker("C’EST BON"));
        addSpacer(8);
        root.addView(text("L’agent s’occupe de la suite.", 36, TEXT, true));
        addSpacer(12);

        int objective = profile.optInt("objective", 0);
        root.addView(paragraph("Ton objectif est de " + objective + " €/mois. Tu peux fermer l’application : le travail continue côté serveur."));
        addSpacer(24);

        JSONObject membership = dashboard.optJSONObject("membership");
        String label = membership == null ? "Compte actif" : membership.optString("label", "Compte actif");
        root.addView(infoCard("Compte", label));
        addSpacer(10);

        JSONObject autopilot = dashboard.optJSONObject("autopilot");
        boolean enabled = autopilot != null && autopilot.optBoolean("enabled", false);
        root.addView(infoCard("Agent", enabled ? "L’agent travaille automatiquement" : "Travail automatique en pause"));
        addSpacer(10);

        double revenue = profile.optDouble("totalRevenue", 0);
        root.addView(infoCard("Revenu déclaré", formatEuro(revenue)));
        addSpacer(24);

        Button refresh = secondaryButton("Actualiser");
        refresh.setOnClickListener(v -> loadDashboard());
        root.addView(refresh, wideParams(50));
        addSpacer(10);
        Button logout = secondaryButton("Déconnexion");
        logout.setOnClickListener(v -> logout());
        root.addView(logout, wideParams(50));
    }

    private void logout() {
        String session = getSession();
        prefs.edit().remove(SESSION_KEY).apply();
        showLogin();
        if (session.isEmpty()) return;
        executor.submit(() -> {
            try {
                requestWithSession("/api/mobile/logout", "POST", new JSONObject(), session);
            } catch (Exception ignored) {
            }
        });
    }

    private void showLoading(String label) {
        clearRoot();
        addSpacer(120);
        root.addView(text("🤖", 40, TEXT, true));
        addSpacer(18);
        root.addView(text(label, 22, TEXT, true));
    }

    private void showRetry(String message) {
        clearRoot();
        addSpacer(90);
        root.addView(text(message, 24, TEXT, true));
        addSpacer(12);
        root.addView(paragraph("Vérifie ta connexion internet puis réessaie."));
        addSpacer(20);
        Button retry = primaryButton("Réessayer");
        retry.setOnClickListener(v -> loadDashboard());
        root.addView(retry, wideParams(54));
    }

    private String safeError(Exception error) {
        String message = error == null ? "erreur inconnue" : String.valueOf(error.getMessage());
        if (message == null || message.isEmpty()) return "erreur inconnue";
        if (message.length() > 120) message = message.substring(0, 120);
        return message.replace("\n", " ").replace("\r", " ");
    }

    private JSONObject request(String path, String method, JSONObject body, boolean withSession) throws Exception {
        return requestWithSession(path, method, body, withSession ? getSession() : "");
    }

    private JSONObject requestWithSession(String path, String method, JSONObject body, String session) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(BASE_URL + path).openConnection();
        connection.setRequestMethod(method);
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(30000);
        connection.setRequestProperty("Accept", "application/json, text/plain, */*");
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36");
        connection.setRequestProperty("Origin", BASE_URL);
        connection.setRequestProperty("Referer", BASE_URL + "/");
        connection.setRequestProperty("Accept-Language", "fr-FR,fr;q=0.9,en;q=0.8");
        if (!session.isEmpty()) connection.setRequestProperty("X-SiteIA-Session", session);

        if (body != null && !"GET".equals(method)) {
            connection.setDoOutput(true);
            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream output = connection.getOutputStream()) {
                output.write(bytes);
            }
        }

        int status = connection.getResponseCode();
        InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
        String responseText = readStream(stream);
        connection.disconnect();

        if (status == 401) throw new UnauthorizedException();
        if (status == 403) return browserRequest(path, method, body, session);
        if (status < 200 || status >= 300) throw new Exception("http_" + status + ":" + responseText);
        return responseText.isEmpty() ? new JSONObject() : new JSONObject(responseText);
    }

    private JSONObject browserRequest(String path, String method, JSONObject body, String session) throws Exception {
        CountDownLatch latch = new CountDownLatch(1);
        AtomicReference<String> result = new AtomicReference<>("");
        AtomicReference<Exception> failure = new AtomicReference<>();
        String bodyJson = body == null ? "null" : JSONObject.quote(body.toString());
        String sessionJson = JSONObject.quote(session == null ? "" : session);
        String pathJson = JSONObject.quote(path);
        String methodJson = JSONObject.quote(method);

        runOnUiThread(() -> runBrowserRequestWhenReady(pathJson, methodJson, bodyJson, sessionJson, result, failure, latch, 0));
        if (!latch.await(35, TimeUnit.SECONDS)) throw new Exception("browser_api_timeout");
        if (failure.get() != null) throw failure.get();

        String raw = result.get();
        Object unwrapped = new org.json.JSONTokener(raw).nextValue();
        String jsonText = unwrapped instanceof String ? (String) unwrapped : String.valueOf(unwrapped);
        JSONObject envelope = new JSONObject(jsonText);
        int status = envelope.optInt("status", 0);
        String text = envelope.optString("text", "");
        if (status == 401) throw new UnauthorizedException();
        if (status < 200 || status >= 300) throw new Exception("web_http_" + status + ":" + text);
        return text.isEmpty() ? new JSONObject() : new JSONObject(text);
    }

    private void runBrowserRequestWhenReady(
        String pathJson, String methodJson, String bodyJson, String sessionJson,
        AtomicReference<String> result, AtomicReference<Exception> failure,
        CountDownLatch latch, int attempt
    ) {
        if (apiWebView == null) {
            failure.set(new Exception("browser_api_unavailable"));
            latch.countDown();
            return;
        }
        if (!apiWebReady) {
            if (attempt >= 120) {
                failure.set(new Exception("browser_api_not_ready"));
                latch.countDown();
                return;
            }
            apiWebView.postDelayed(() -> runBrowserRequestWhenReady(pathJson, methodJson, bodyJson, sessionJson, result, failure, latch, attempt + 1), 100);
            return;
        }

        String script = "(async()=>{try{" +
            "const p=" + pathJson + ";const m=" + methodJson + ";const b=" + bodyJson + ";const s=" + sessionJson + ";" +
            "const h={'Accept':'application/json','Content-Type':'application/json'};if(s)h['X-SiteIA-Session']=s;" +
            "const o={method:m,headers:h};if(m!=='GET'&&b!==null)o.body=b;" +
            "const r=await fetch(p,o);const t=await r.text();return JSON.stringify({status:r.status,text:t});" +
            "}catch(e){return JSON.stringify({status:0,text:String(e)});}})()";
        apiWebView.evaluateJavascript(script, value -> {
            result.set(value == null ? "\"{\\\"status\\\":0,\\\"text\\\":\\\"empty_result\\\"}\"" : value);
            latch.countDown();
        });
    }

    private String readStream(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder builder = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) builder.append(line);
        }
        return builder.toString();
    }

    private String getSession() {
        return prefs.getString(SESSION_KEY, "");
    }

    private String formatEuro(double value) {
        if (Math.rint(value) == value) return ((long) value) + " €";
        return String.format(java.util.Locale.FRANCE, "%.2f €", value);
    }

    private TextView kicker(String value) {
        TextView view = text(value, 11, ACCENT, true);
        view.setLetterSpacing(0.08f);
        return view;
    }

    private TextView paragraph(String value) {
        TextView view = text(value, 15, MUTED, false);
        view.setGravity(Gravity.CENTER);
        view.setLineSpacing(0, 1.25f);
        return view;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(color);
        view.setTextSize(size);
        view.setGravity(Gravity.CENTER);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private TextView securityNote(String value) {
        TextView view = paragraph("🔒  " + value);
        view.setTextSize(13);
        return view;
    }

    private TextView infoCard(String label, String value) {
        TextView view = text(label + "\n" + value, 15, TEXT, true);
        view.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        view.setLineSpacing(dp(3), 1f);
        view.setPadding(dp(16), dp(12), dp(16), dp(12));
        view.setBackground(panelDrawable());
        return view;
    }

    private Button primaryButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(DARK_TEXT);
        button.setTextSize(15);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(ACCENT);
        bg.setCornerRadius(dp(14));
        button.setBackground(bg);
        return button;
    }

    private Button secondaryButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(TEXT);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setBackground(panelDrawable());
        return button;
    }

    private GradientDrawable panelDrawable() {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(PANEL);
        bg.setStroke(dp(1), BORDER);
        bg.setCornerRadius(dp(14));
        return bg;
    }

    private LinearLayout.LayoutParams wideParams(int heightDp) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(heightDp)
        );
        params.setMargins(0, 0, 0, 0);
        return params;
    }

    private void addSpacer(int heightDp) {
        Space space = new Space(this);
        root.addView(space, new LinearLayout.LayoutParams(1, dp(heightDp)));
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        if (apiWebView != null) {
            apiWebView.stopLoading();
            apiWebView.destroy();
            apiWebView = null;
        }
        super.onDestroy();
    }

    private static final class UnauthorizedException extends Exception {
    }
}
