# NutriCoach Android — APK de test

Cette version ouvre NutriCoach comme une application Android en portrait, sans barre de navigateur.

## Fonctions Android incluses
- affichage téléphone portrait ;
- navigation Retour Android ;
- stockage web/cookies ;
- choix d'image ou fichier ;
- prise de photo depuis les champs de scan ;
- liens externes ouverts dans le navigateur ;
- NutriCoach reste synchronisé avec https://nutricoach-t6aqdo.v2.appdeploy.ai/.

## Compilation automatique
Le workflow `.github/workflows/build-apk.yml` compile un APK debug signé automatiquement et crée l'artifact `NutriCoach-Android-test`.

Le fichier final s'appelle `NutriCoach-Android-test.apk`.
