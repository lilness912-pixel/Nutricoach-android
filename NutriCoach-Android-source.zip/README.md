# Site IA Agent Android

Application Android native légère qui affiche Site IA Agent dans un WebView sécurisé et conserve le backend AppDeploy existant.

## Build

- Java 17
- Android SDK 35
- Gradle 8.10.2
- Commande : `gradle :app:assembleDebug`

APK attendu : `app/build/outputs/apk/debug/app-debug.apk`
