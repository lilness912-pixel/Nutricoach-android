Site IA Agent Android v3

- Correctif connexion Android/AppDeploy
- Content-Type JSON strict
- Message de diagnostic réseau/auth plus précis
- Premium Fondateur reste déterminé côté serveur
