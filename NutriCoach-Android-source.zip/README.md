# Site IA Agent Android 1.1

Application Android native pour Site IA Agent.

- Connexion sécurisée via Chrome puis retour automatique dans l'application.
- Aucun mot de passe stocké dans l'APK.
- Session mobile dédiée et révocable côté serveur.
- Parcours natif simplifié : connexion → objectif → Valider → agent autonome.
- Le statut Fondateur / Premium à vie reste décidé côté serveur.
