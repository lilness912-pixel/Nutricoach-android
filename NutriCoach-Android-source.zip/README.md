Site IA Agent Android v4. Native UI. Browser-based API fallback added for AppDeploy HTTP 403 responses. Founder/Premium status remains server-side.
