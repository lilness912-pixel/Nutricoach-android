# Site IA Agent Android v5

Correctif de connexion : le fallback WebView attend maintenant réellement la fin de la requête asynchrone via un pont JavaScript sécurisé, au lieu de lire une Promise trop tôt.

- Package : com.siteiaagent.app
- Version : 1.3.0 (4)
- Authentification : Chrome + deep link sécurisé
- API : appel natif puis fallback même origine AppDeploy via WebView
- WebView verrouillée sur le domaine Site IA Agent
