# Site IA Agent — Android FINAL

Cette version est l'architecture finale prévue pour AppDeploy.

- Aucun appel API n'est effectué depuis Java/Android.
- Aucun `HttpURLConnection`.
- Aucun `fetch()` injecté depuis Android.
- La WebView charge uniquement le frontend AppDeploy.
- Tous les appels backend doivent être effectués dans React via `api.get/api.post` de `@appdeploy/client`.
- La connexion s'ouvre dans Chrome, puis revient via `siteiaagent://auth?code=...`.
- Le code est transmis au frontend AppDeploy via `?androidApp=1&linkCode=...`.

Ne compiler cette version qu'après déploiement du correctif frontend/backend AppDeploy correspondant.
